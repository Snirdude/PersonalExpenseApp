package com.example.personal_expense_app;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
  
}
